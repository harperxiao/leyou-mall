$(function() {
    $('input,textarea').placeholder();
})